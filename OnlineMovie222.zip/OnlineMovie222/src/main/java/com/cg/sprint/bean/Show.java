package com.cg.sprint.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="showdetail")
public class Show 
{
     @Id
     @Column(name="show_id")
     int showId;
     @Column(name="show_name")
     String showName;
     @Column(name="show_time")
     String time;
     @OneToOne
     @JoinColumn(name="movie_id")
     Movie movie;
     public Show() { }
	public Show(int showId, String showName, String time, Movie movie) {
		super();
		this.showId = showId;
		this.showName = showName;
		this.time = time;
		this.movie = movie;
	}
	public int getShowId() {
		return showId;
	}
	public void setShowId(int showId) {
		this.showId = showId;
	}
	public String getShowName() {
		return showName;
	}
	public void setShowName(String showName) {
		this.showName = showName;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public Movie getMovie() {
		return movie;
	}
	public void setMovie(Movie movie) {
		this.movie = movie;
	}
	
}
