package com.cg.sprint.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.sprint.bean.TicketBooking;

public interface TicketBookingDAO extends JpaRepository<TicketBooking,Integer>
{
    
}