package com.cg.sprint.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.sprint.bean.User;

public interface UserDAO  extends JpaRepository<User,String>
{

}
