package com.cg.sprint.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.sprint.bean.TicketBooking;
import com.cg.sprint.dao.TicketBookingDAO;
@Service
public class TicketBookingService 
{
	@Autowired
    TicketBookingDAO bDao;
    public void setbDao(TicketBookingDAO bDao) { this.bDao=bDao; }
    
    @Transactional(readOnly=true)
    public Optional<TicketBooking> getBooking(int bookingId)
    {
    	return bDao.findById(bookingId);
    }
    
    @Transactional(readOnly=true)
    public List<TicketBooking> getBookings()
    {
    	return bDao.findAll();
    }
    
    @Transactional()
    public void insertBooking(TicketBooking booking)
    {
    	bDao.save(booking);
    }
    
    @Transactional
    public void deleteBooking(int bookingId)
    {
    	bDao.deleteById(bookingId);
    }

}
