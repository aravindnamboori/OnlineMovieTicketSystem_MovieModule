package com.cg.sprint.bean;

public class Booking {

}
