package com.cg.sprint.controller;

public class BookingController {

}
