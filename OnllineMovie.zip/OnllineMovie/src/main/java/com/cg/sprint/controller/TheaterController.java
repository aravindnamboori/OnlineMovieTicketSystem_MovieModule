package com.cg.sprint.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.sprint.bean.Theater;
import com.cg.sprint.service.TheaterService;
@RestController
public class TheaterController 
{
	@Autowired
	RestTemplate restTemplate;
	   public void setRestTemplate(RestTemplate restTemplate)
	   {
		   this.restTemplate=restTemplate;
	   }
	TheaterService theaterService;
	public void setTheaterService(TheaterService theaterService)
	{
		this.theaterService=theaterService;
	}
	//getTheater
	@GetMapping(value="/getTheater/{theaterId}",produces="application/json")
	   public ResponseEntity<Optional<Theater>> getTheater(@PathVariable int theaterId)
	   {
	 	  Optional<Theater> theater =  theaterService.getTheater(theaterId);
	 	  if(theater.isPresent())
	 		  return new ResponseEntity<Optional<Theater>>(theater,HttpStatus.OK);
	 	  return new ResponseEntity<Optional<Theater>>(theater,HttpStatus.NOT_FOUND);
	   }
		//AddTheater
		@PostMapping(value="/addTheater",consumes="application/json")
		   public ResponseEntity<String> insertTheater(@RequestBody()Theater theater)
		   {
			   String message="Theater Inserted Successfully";
			   if(theaterService.insertTheater(theater)==null)
				   message="Theater Insertion Failed";
			   return new ResponseEntity<String>(message,HttpStatus.BAD_REQUEST);
		   }
		//DeleteTheater
		@DeleteMapping("/deleteTheater/{theaterId}")
		   public String deleteTheater(@PathVariable int theaterId)
		   {
			return theaterService.deleteTheater(theaterId);
		   }

}
