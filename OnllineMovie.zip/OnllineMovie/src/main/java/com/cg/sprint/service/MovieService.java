package com.cg.sprint.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sprint.bean.Movie;
import com.cg.sprint.dao.MovieDAO;

@Service
public class MovieService 
{
	@Autowired
    MovieDAO mdao;
    public void setBdao(MovieDAO mdao) 
    {
    	this.mdao=mdao;
    }
    
    public Movie insertMovie(Movie movie)
    {
        return mdao.save(movie);
    }
    
    public Optional<Movie> getMovie(int movieId)
    {
    	return mdao.findById(movieId);
    }
  
    public List<Movie> getMovies()
    {
    	return mdao.findAll();
    }
    public String deleteMovie(int movieId)
    {
    	
    	mdao.deleteById(movieId);
    	return "Movie Deleted Successfully";
    }
    	
    	
    	

}
