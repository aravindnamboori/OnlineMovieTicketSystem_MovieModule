package com.cg.sprint.service;



import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.sprint.bean.Theater;
import com.cg.sprint.dao.TheaterDAO;
@Service
public class TheaterService 
{
	@Autowired
	TheaterDAO tdao;
	public void setTdao(TheaterDAO tdao)
	{
		this.tdao=tdao;
	}
	//InsertTheater
	@Transactional
    public Theater insertTheater(Theater theater)
    {
        return tdao.save(theater);
    }
	@Transactional(readOnly=true)
	public Optional<Theater> getTheater(int theaterId)
	{
		return tdao.findById(theaterId);
	}
    //DeleteTheater
    public String deleteTheater(int theaterId) 
    {
    	tdao.deleteById(theaterId);
    	return "Theater Deleted Successfully";
    }

}
